# Expense Tracker 💰📊

A simple command-line expense tracker to help manage personal finances.

## Features
- 📌 Add and categorize expenses
- 📊 View all expenses

## How to Use
1. Run `python expense_tracker.py`
2. Add expenses programmatically

## License
MIT License
